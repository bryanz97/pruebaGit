<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ config('app.name') }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/owl.carousel@2.3.4/dist/assets/owl.carousel.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {}

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link {{ Route::is('index') ? 'active' : '' }}" aria-current="page"
                            href="{{ route('index') }}">Inicio</a>
                    </li>
                    @guest
                        <li class="nav-item">
                            <a class="nav-link {{ Route::is('login') ? 'active' : '' }}"
                                href="{{ route('login') }}">Acceder</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ Route::is('register') ? 'active' : '' }}"
                                href="{{ route('register') }}">Registro</a>
                        </li>
                    @endguest
                    @auth
                        <li class="nav-item">
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button class="btn">Salir</a>
                            </form>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>
    <div class="container flex-1">
        @yield('content')
    </div>


    <footer class="bg-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    Integrantes
                    <ul>
                        <li>Alejandro Alborno</li>
                        <li>Carlos Cañete</li>
                        <li>Bryan Zalazar</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <div class="text-end">
                        Proyecto de aplicaciones web 2021.1
                        <br>
                        Tercer Parcial
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                    &copy; {{ date('Y') }}
                </div>
            </div>
        </div>
    </footer>
    @yield('scripts')
</body>


</html>
