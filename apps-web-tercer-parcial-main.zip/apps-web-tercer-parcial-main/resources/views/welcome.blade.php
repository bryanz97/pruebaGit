@extends('layouts.app')

@section('content')

    <h1>¡Elabora tus mejores recetas!</h1>

    <div class="div py-3">
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="https://placeimg.com/900/400/any?v={{ rand(1, 10) }}" class="w-100">
                </div>
                <div class="carousel-item">
                    <img src="https://placeimg.com/900/400/any?v={{ rand(1, 10) }}" class="w-100">
                </div>
                <div class="carousel-item">
                    <img src="https://placeimg.com/900/400/any?v={{ rand(1, 10) }}" class="w-100">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <p>
        Dui id euismod ac nec rhoncus. Nulla taciti curae; consequat suscipit hendrerit, facilisis senectus? Scelerisque
        semper dignissim pellentesque dignissim dictumst magna duis at pharetra. Consequat maecenas egestas nisi suspendisse
        auctor fusce sed feugiat laoreet. Varius velit ultrices eget torquent habitasse ut nibh lacinia quam phasellus
        facilisi parturient. Cras aenean pellentesque etiam conubia varius dictumst.
    </p>
    <p>
        Interdum condimentum mauris nostra consequat diam ligula sodales nec malesuada vestibulum. Metus a quisque nam
        integer posuere, pretium fames facilisis! Eget praesent venenatis nostra pulvinar mi. Proin conubia dis eleifend sed
        tincidunt turpis aptent tempus at. A primis eleifend urna pellentesque nascetur sem dictumst dapibus vivamus sociis
        per gravida. Himenaeos eget dolor lectus, rutrum curae;. Phasellus felis leo eleifend feugiat mi laoreet viverra
        pulvinar vehicula fringilla. Laoreet eget aptent.
    </p>
    <p>
        Orci tempor semper dui fermentum nisi, non orci feugiat quam. Dui ante amet ac est massa nec erat natoque. Pretium
        quisque nullam pulvinar blandit blandit cubilia dictumst porta placerat consectetur sollicitudin. Donec convallis
        aptent non placerat hendrerit magna, ridiculus ullamcorper eget molestie senectus. Egestas accumsan lacinia risus
        sit auctor interdum magna, pretium feugiat lobortis. Blandit augue faucibus dictumst ultricies fringilla facilisi
        pulvinar dapibus. Commodo risus lacus metus suspendisse tempor massa. Ultrices purus magnis molestie cubilia
        scelerisque! Fermentum himenaeos.
    </p>
    <p>
        Fermentum feugiat tempus sapien. Varius nullam ante hac metus ipsum sociis iaculis cursus penatibus posuere congue
        netus. Leo ipsum risus gravida volutpat sapien senectus cursus! Himenaeos ligula nostra orci donec vehicula potenti.
        Lorem aliquam scelerisque eu. Tortor nunc venenatis rhoncus curae; proin iaculis tortor duis curae; dis nullam!
        Mauris dis nunc ac rhoncus nisi adipiscing felis massa volutpat augue vitae. Volutpat amet torquent quam aenean
        ligula.
    </p>
    <p>
        Erat duis quam lacus ultrices diam taciti sagittis penatibus turpis maecenas sapien molestie. Elit adipiscing diam
        primis turpis ante nostra congue vivamus accumsan convallis. Habitant phasellus primis et. Mauris et dapibus
        pharetra tincidunt tellus tincidunt ullamcorper mattis odio sem quam. Quam arcu arcu cursus viverra cursus sem.
        Tellus habitant senectus velit sodales nec mi feugiat eu iaculis montes? Turpis congue sollicitudin praesent turpis
        sem platea. Ullamcorper erat dui a.
    </p>

    <div class="d-block py-5">
        <button type="button" class="btn btn-primary">Primary</button>
    </div>

    <p>
        Orci tempor semper dui fermentum nisi, non orci feugiat quam. Dui ante amet ac est massa nec erat natoque. Pretium
        quisque nullam pulvinar blandit blandit cubilia dictumst porta placerat consectetur sollicitudin. Donec convallis
        aptent non placerat hendrerit magna, ridiculus ullamcorper eget molestie senectus. Egestas accumsan lacinia risus
        sit auctor interdum magna, pretium feugiat lobortis. Blandit augue faucibus dictumst ultricies fringilla facilisi
        pulvinar dapibus. Commodo risus lacus metus suspendisse tempor massa. Ultrices purus magnis molestie cubilia
        scelerisque! Fermentum himenaeos.
    </p>
    <p>
        Fermentum feugiat tempus sapien. Varius nullam ante hac metus ipsum sociis iaculis cursus penatibus posuere congue
        netus. Leo ipsum risus gravida volutpat sapien senectus cursus! Himenaeos ligula nostra orci donec vehicula potenti.
        Lorem aliquam scelerisque eu. Tortor nunc venenatis rhoncus curae; proin iaculis tortor duis curae; dis nullam!
        Mauris dis nunc ac rhoncus nisi adipiscing felis massa volutpat augue vitae. Volutpat amet torquent quam aenean
        ligula.
    </p>
    <p>
        Erat duis quam lacus ultrices diam taciti sagittis penatibus turpis maecenas sapien molestie. Elit adipiscing diam
        primis turpis ante nostra congue vivamus accumsan convallis. Habitant phasellus primis et. Mauris et dapibus
        pharetra tincidunt tellus tincidunt ullamcorper mattis odio sem quam. Quam arcu arcu cursus viverra cursus sem.
        Tellus habitant senectus velit sodales nec mi feugiat eu iaculis montes? Turpis congue sollicitudin praesent turpis
        sem platea. Ullamcorper erat dui a.
    </p>

    <div class="owl-carousel">
        <div class="d-flex justify-center"> <img src="{{ asset('images/Amandau.jpg') }}" /> </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/bellini.png') }}" /> </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/BenditasEmpanadas.jpg') }}" /> </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/donvito-preview1.jpg') }}" /> </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/elheladero.jpg') }}" /> </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/ilmangiare.jpg') }}" /> </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/LaCasaDeLaResposteriaPreview.jpg') }}" />
        </div>
        <div class="d-flex justify-center"> <img src="{{ asset('images/milanesa.webp') }}" /> </div>
    </div>


@endsection

@section('scripts')

    <script src="https://cdn.jsdelivr.net/npm/owl.carousel@2.3.4/dist/owl.carousel.min.js"></script>

    <script>
        $(document).ready(function() {
            $(".owl-carousel").owlCarousel({
                items: 5,
                loop: true,
                center: true,
                autoplay: true,
            });
        });
    </script>
@endsection
